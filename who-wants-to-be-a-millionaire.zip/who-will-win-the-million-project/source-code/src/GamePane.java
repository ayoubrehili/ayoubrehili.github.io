import java.util.ArrayList;
import java.util.Collections;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;

public class GamePane extends Pane implements ScreenBounds {

    // حتى نستطيع إستدعاء دوال تشغيل الأصوات التي جهزناها فيه Sounds هنا قمنا بإنشاء كائن من الكلاس
    Sounds mySounds = new Sounds();

    // هنا قمنا بإنشاء كل العناصر الظاهرة في النافذة
    Button btnExit = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/res/images/Close-icon.png"))));
    Button btnBack = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/res/images/Go-back-icon.png"))));
    Button btnCallFriend = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/res/images/Phone-icon.png"))));
    Button btnAskAudience = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/res/images/User-Group-icon.png"))));
    Button btnDeleteTwoAnswers = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/res/images/Number-2-icon.png"))));
    Button btnPlayGame = new Button("إبدأ الآن");
    Label timerLabel = new Label();                  // هذا الكائن سنعرض عليه التوقيت الباقي للإجابة عن الأسئلة و الذي يظهر عندما تبدأ اللعبة
    StackPane playButtonPane = new StackPane();      // هذه الحاوية الأساسية التي وضعنا فيها كل شيء, و التي بدورها ستظهره في وسط النافذة
    ArrayList<Label> moneyLabels = new ArrayList();  // ArrayList موجود في هذا الـ Label حاوية المال التي تظهر في يمين النافذة, كل مربع فيها عبارة

    // هذا الكائن يمثل الحاوية التي يظهر فيها السؤال
    GameQuestionShape questionShape = new GameQuestionShape(640, 60);

    // هذه الكائنات تمثل الأزرار التي تظهر عليها الإجابات المحتلمة لكل سؤال
    GameAnswerButton answer1 = new GameAnswerButton(320, 40, 320, 10);
    GameAnswerButton answer2 = new GameAnswerButton(320, 40, 0, 10);
    GameAnswerButton answer3 = new GameAnswerButton(320, 40, 320, 60);
    GameAnswerButton answer4 = new GameAnswerButton(320, 40, 0, 60);

    // محتوى نافذة اللعب سيتم تقسيمه فعلياً على الخمس حاوية التالية
    HBox hBox = new HBox();
    VBox vBox = new VBox();
    Pane answersPane = new Pane();
    HBox topMenuBox = new HBox(10);
    VBox moneyBox = new VBox(4);

    // سنخزن فيه جميع الأسئلة و الإجابات التي قمنا بإعدادها للعبة questions الكائن
    Questions questions;
    
    // سنخزن فيه في كل مرة سؤال جديد مع الإجابات الخاصة بهذا السؤال question الكائن
    Question question;

    // سنستخدم جميع المتغيرات التالية لإظهار المؤثرات بأوقات محددة بالإضافة إلى حفظ نشاط اللاعب بشكل مؤقت
    boolean isGameOver;
    int InitialSeconds;
    Integer RemainingSeconds;
    boolean anAnswerButtonIsClicked;
    boolean isAnswerCorrect;
    String whichButtonIsClicked;
    int correctAnswersCounter;
    int totalEarning;

    // هذا الكائن سنستخدمه عند إعطاء المستخدم مهلة 30 ثانية للإجابة بالإضافة إلى المؤثرات التي سنعرضها خلال فترات مختلفة
    Timeline timeline;
    
    // هذا المتغير سنستخدمه لتخزين عدد الإجابات التي يمكن للمستخدم أن أن ينقر عليها و فعلياً ستتغير قيمته فقط عندما يقوم بحذف إجابتين
    int hiddenButtonsCounter;

    // هذا المتغير سنستخدمه كمؤشر لمعرفة ما إن كان المستخدم قد إستخدم وسيلة الإتصال بصديق أم لا
    boolean aFriendIsCalled;

    // هذا المتغير سنستخدمه كمؤشر لمعرفة ما إن كان المستخدم قد إستخدم وسيلة سؤال الجمهور أم لا
    boolean userIsAskingAudience;

    // لكل شيء Reset هذه الدالة يجب استدعاءها في كل مرة سيتم فيها البدء باللعب بهدف أن تقوم بتصفير اللعبة أو تفعل ما نسميه
    public void initialValues() {
        questions = new Questions();
        isGameOver = false;
        timeline = new Timeline();
        InitialSeconds = 30;
        RemainingSeconds = InitialSeconds;
        anAnswerButtonIsClicked = false;
        isAnswerCorrect = false;
        whichButtonIsClicked = "";
        correctAnswersCounter = 0;
        totalEarning = 0;
        hiddenButtonsCounter = 0;
        aFriendIsCalled = false;
        userIsAskingAudience = false;
    }

    // هذه الدالة يجب استدعاءها عندما يتم بدأ اللعبة و هي بدورها ستقوم فقط باستدعاء الدوال الموضوعة فيها بالترتيب
    public void playGame() {
        initialValues();
        mySounds.clickSound();
        displayNewQestion();
        checkAnswer();
    }

    // هذه الدالة يجب استدعاءها عندما يقوم المستخدم باختيار إجابة صحيحة بهدف أن تحدد له كم ربح حتى الآن, فعلياً ستجعل المرحلة التي وصل إليها تظهر بلون متميز
    public void markLastPassedLevel() {
        for (Label label : moneyLabels) {
            label.setTextFill(Color.YELLOW);
            label.setBackground(new Background(new BackgroundFill(Color.BLACK, new CornerRadii(5), Insets.EMPTY)));
        }
        moneyLabels.get(correctAnswersCounter).setTextFill(Color.WHITE);
        moneyLabels.get(correctAnswersCounter).setBackground(new Background(new BackgroundFill(Color.BLUE, new CornerRadii(5), Insets.EMPTY)));
        totalEarning = Integer.parseInt(moneyLabels.get(correctAnswersCounter).getText());
    }

    // و من ثم عرضه في واجهة المستخدم questions هذه الدالة تستخدم لجلب سؤال جديد بشكل عشوائي من الكائن
    // نلاحظ أنه قبل جلب أي سؤال جديد يجب التأكد من عدة أمور, فمثلاً إذا كان المستخدم
    // قد أجاب عن 15 سؤال بشكل صحيح, يجب إعلامه بأنه قد ربح بدل عرض سؤال جديد أمامه
    public void displayNewQestion() {        
        if (userIsAskingAudience == true) {
            userIsAskingAudience = false;
        }
        
        if (aFriendIsCalled == true) {
            aFriendIsCalled = false;
        }

        if (correctAnswersCounter >= 15) {
            timeline.stop();
            ResultPane.setResult(correctAnswersCounter, totalEarning);
            Main.STAGE.getScene().setRoot(Main.PANE_RESULT);
        }
        else {
            if (hiddenButtonsCounter != 0) {
                hiddenButtonsCounter = 0;
                answer1.show();
                answer2.show();
                answer3.show();
                answer4.show();
            }

            question = questions.getQuestion();
            Collections.shuffle(question.answers);

            answer1.setDefaultBg();
            answer2.setDefaultBg();
            answer3.setDefaultBg();
            answer4.setDefaultBg();

            questionShape.setText(question.getPhrase());
            answer1.setText(question.getAnswer(0).getText());
            answer2.setText(question.getAnswer(1).getText());
            answer3.setText(question.getAnswer(2).getText());
            answer4.setText(question.getAnswer(3).getText());
        }
    }

    // هذه الدالة تستخدم لنقل اللاعب إلى الحاوية التي تعرض له نتيجته
    public void displayResult() {
        timeline.stop();
        ResultPane.setResult(correctAnswersCounter, totalEarning);
        Main.STAGE.getScene().setRoot(Main.PANE_RESULT);
    }

    // هذه الدالة تستخدم للتأكد من إجابة المستخدم, مع الإشارة إلى أنها أكثر دالة معقدة في كل هذا البرنامج
    // حيث أنها تحلل كل ما يقوم به المستخدم, لعرض كل الأشياء التي يجب أن تظهر له في التوقيت المناسب
    public void checkAnswer() {
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(1), (ActionEvent event) -> {

            if (RemainingSeconds == 0) {
                timerLabel.setText("إنتهى الوقت");
                // سيتم استدعاءها بعد ثانيتين displayResult() قمنا بإضافة الأسطر الثلاثة التالية فقك لضمان أن الدالة
                RemainingSeconds = -5;
                isAnswerCorrect = false;
                anAnswerButtonIsClicked = true;
            }
            else {
                // إذا لم يقم المستخدم بالنقر على أي إجابة, سيتم عرض الوقت المتبقي له للإجابة فقط
                if (anAnswerButtonIsClicked == false) {
                    // في حال قام بالنقر على زر الإتصال بصديق, سيتم طباعة الجمل التالية مع عرض كل جملة مدة ثانيتين تقريباً
                    // و في النهاية سيتم عرض الجواب الصحيح أمامه
                    if (aFriendIsCalled == true) {
                        if (RemainingSeconds == 40) {
                            timerLabel.setText("يتم الآن الإتصال بصديقك");
                        } else if (RemainingSeconds == 37) {
                            timerLabel.setText("مرحباً بك أيها الصديق");
                        } else if (RemainingSeconds == 34) {
                            timerLabel.setText("معك 30 ثانية للإجابة على السؤال التالي");
                        } else if (RemainingSeconds == 30) {
                            timerLabel.setText(question.getPhrase());
                        } else if (RemainingSeconds == 22) {
                            timerLabel.setText("أعتقد أن الجواب الصحيح هو");
                        } else if (RemainingSeconds == 18) {
                            if (question.getAnswer(0).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(0).getText());
                            } else if (question.getAnswer(1).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(1).getText());
                            } else if (question.getAnswer(2).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(2).getText());
                            } else if (question.getAnswer(3).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(3).getText());
                            }
                        } else if (RemainingSeconds == 1) {
                            aFriendIsCalled = false;
                            RemainingSeconds = InitialSeconds;
                        }
                    }
                    /////////////////////////////////////////////////////////////
                    // في حال قام بالنقر على زر طلب المساعدة من الجمهور, سيتم طباعة الجمل التالية مع عرض كل جملة مدة خمس ثواني
                    // و في النهاية سيتم عرض الجواب الصحيح أمامه
                    else if (userIsAskingAudience == true) {
                        if (RemainingSeconds == 40) {
                            timerLabel.setText("سيساعدك الآن الجمهور باختيار الإجابة الصحيحة");
                        } else if (RemainingSeconds == 35) {
                            timerLabel.setText("النسبة الأكبر من الأصوات إختارت الإجابة");
                        } else if (RemainingSeconds == 30) {
                            if (question.getAnswer(0).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(0).getText());
                            } else if (question.getAnswer(1).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(1).getText());
                            } else if (question.getAnswer(2).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(2).getText());
                            } else if (question.getAnswer(3).isCorrect == true) {
                                timerLabel.setText(question.getAnswer(3).getText());
                            }
                        } else if (RemainingSeconds == 20) {
                            userIsAskingAudience = false;
                            RemainingSeconds = InitialSeconds;
                        }
                    }
                    // هذا الأمر, يعني أنه سيتم عرض الوقت المتبقي للإجابة في حال كان المستخدم لا يطلب حالياً مساعدة صديق أو مساعدة جمهور
                    else {
                        timerLabel.setText(RemainingSeconds.toString());
                    }
                    RemainingSeconds--;
                }
                // إذا تم النقر على أي إجابة, سيتم التأكد من ما إذا كانت الإجابة صحيحة أم لا و على أساس ذلك سيتم عرض جمل معينة أمامه
                else if (anAnswerButtonIsClicked == true) {

                    // أكبر من 0, سيتم عرض جملة جديدة كل ثانيتين RemainingSeconds إذا كانت قيمة المتغير 
                    if (RemainingSeconds > 0) {
                        RemainingSeconds = 0;
                    }

                    // RemainingSeconds بعدها سيتم إنقاص ثانية واحدة من المتغير
                    RemainingSeconds--;

                    // هنا قمنا بتحديد الجملة الأولى التي سيتم طباعتها
                    if (RemainingSeconds <= -2 && RemainingSeconds >= -5) {
                        if (isAnswerCorrect == true) {
                            timerLabel.setText("الإجابة صحيحة");
                        } else {
                            timerLabel.setText("الإجابة غير صحيحة");
                            // إذا كان المستخدم قد قام باختيار إجابة خاطئة, سيتم جعل لون خلفية الزر الذي نقر عليه برتقالي
                            switch (whichButtonIsClicked) {
                                case "answer1":
                                    answer1.setLooseBg();
                                    break;
                                case "answer2":
                                    answer2.setLooseBg();
                                    break;
                                case "answer3":
                                    answer3.setLooseBg();
                                    break;
                                case "answer4":
                                    answer4.setLooseBg();
                                    break;
                            }
                            if (RemainingSeconds == -3) {
                                // بعد أن يقوم المستخدم باختيار أي إجابة, سيتم تلوين خلفية الإجابة الصحيحة باللون الأخضر
                                if (question.getAnswer(0).isCorrect == true) {
                                    answer1.setWinBg();
                                } else if (question.getAnswer(1).isCorrect == true) {
                                    answer2.setWinBg();
                                } else if (question.getAnswer(2).isCorrect == true) {
                                    answer3.setWinBg();
                                } else if (question.getAnswer(3).isCorrect == true) {
                                    answer4.setWinBg();
                                }
                            }
                        }
                    }
                    // هنا قمنا بتحديد الجملة الثانية التي سيتم طباعتها
                    else if (RemainingSeconds <= -6 && RemainingSeconds >= -9) {
                        if (isAnswerCorrect == true) {
                            if (RemainingSeconds == -6) {
                                timerLabel.setText("أصبح رصيدك " + moneyLabels.get(correctAnswersCounter).getText());
                                markLastPassedLevel();
                                correctAnswersCounter++;
                            }

                            // حتى يتم نقله لصفحة النتيجة displayResult() إذا تم إنهاء جميع الأسئلة بنجاح سيتم إستدعاء الدالة
                            if (correctAnswersCounter == 16 && RemainingSeconds == -9) {
                                displayResult();
                            }
                        } 
                        else {
                            if (RemainingSeconds == -9) {
                                displayResult();
                            }
                        }
                    }
                    // هنا قمنا بتحديد الجملة الثالثة التي سيتم طباعتها
                    else if (RemainingSeconds <= -10 && RemainingSeconds >= -13) {
                        timerLabel.setText("إستعد للسؤال التالي");
                    } 
                    // هنا قمنا بوضع السؤال التالي للمستخدم
                    else if (RemainingSeconds <= -14 && RemainingSeconds >= -16) {
                        if (RemainingSeconds == -16) {
                            anAnswerButtonIsClicked = false;
                            RemainingSeconds = InitialSeconds;
                            displayNewQestion();
                        }
                    }
                }
            }

            // إذا كان المستخدم يملك 10 ثواني أو أقل للإجابة سيتم تشغيل صوت يشبه دقة الثانية في كل ثانية
            if (RemainingSeconds >= 0
                    && RemainingSeconds < 10
                    && aFriendIsCalled == false
                    && userIsAskingAudience == false) {
                mySounds.clockTickSound();
            }
        }
        ));
        // كما كان قبل تشغيله. أي كأنها تقوم بتصفيره timeline حتى تعيد الكائن playFromStart() الدالة 
        timeline.playFromStart();
    }

    // هذا كونستركتور الكلاس
    public GamePane() {

        answer1.setOnMousePressed((MouseEvent t) -> {
            if (anAnswerButtonIsClicked == false) {
                answer1.setWinBg();
                if (question.getAnswer(0).isCorrect == true) {
                    mySounds.ClickOnCorrectAnswerSound();
                    isAnswerCorrect = true;
                } else {
                    mySounds.ClickOnWrongAnswerSound();
                    isAnswerCorrect = false;
                }
                anAnswerButtonIsClicked = true;
                whichButtonIsClicked = "answer1";
            }
        });

        answer2.setOnMousePressed((MouseEvent t) -> {
            if (anAnswerButtonIsClicked == false) {
                answer2.setWinBg();
                if (question.getAnswer(1).isCorrect == true) {
                    mySounds.ClickOnCorrectAnswerSound();
                    isAnswerCorrect = true;
                } else {
                    mySounds.ClickOnWrongAnswerSound();
                    isAnswerCorrect = false;
                }
                anAnswerButtonIsClicked = true;
                whichButtonIsClicked = "answer2";
            }
        });

        answer3.setOnMousePressed((MouseEvent t) -> {
            if (anAnswerButtonIsClicked == false) {
                answer3.setWinBg();
                if (question.getAnswer(2).isCorrect == true) {
                    mySounds.ClickOnCorrectAnswerSound();
                    isAnswerCorrect = true;
                } else {
                    mySounds.ClickOnWrongAnswerSound();
                    isAnswerCorrect = false;
                }
                anAnswerButtonIsClicked = true;
                whichButtonIsClicked = "answer3";
            }
        });

        answer4.setOnMousePressed((MouseEvent t) -> {
            if (anAnswerButtonIsClicked == false) {
                answer4.setWinBg();
                if (question.getAnswer(3).isCorrect == true) {
                    mySounds.ClickOnCorrectAnswerSound();
                    isAnswerCorrect = true;
                } else {
                    mySounds.ClickOnWrongAnswerSound();
                    isAnswerCorrect = false;
                }
                anAnswerButtonIsClicked = true;
                whichButtonIsClicked = "answer4";
            }
        });

        this.setPrefSize(WIDTH, HEIGHT);
        setGameImage();

        answersPane.setPrefSize(640, 100);
        moneyBox.setPrefSize(130, 510);

        btnExit.setPrefSize(100, 50);
        btnBack.setPrefSize(100, 50);
        btnCallFriend.setPrefSize(100, 50);
        btnAskAudience.setPrefSize(100, 50);
        btnDeleteTwoAnswers.setPrefSize(100, 50);

        timerLabel.setPrefSize(640, 300);
        timerLabel.setFont(new Font(30));
        timerLabel.setTextFill(Color.WHITE);
        timerLabel.setContentDisplay(ContentDisplay.CENTER);
        timerLabel.setAlignment(Pos.CENTER);

        String btnStyle = "-fx-focus-color: transparent; -fx-border-width:2; -fx-border-color: #87cefa; -fx-border-radius:50; -fx-background-radius:50; -fx-background-color:rgba(30, 30, 30, 0.5); -fx-cursor: hand;";
        btnExit.setStyle(btnStyle);
        btnBack.setStyle(btnStyle);
        btnCallFriend.setStyle(btnStyle);
        btnAskAudience.setStyle(btnStyle);
        btnDeleteTwoAnswers.setStyle(btnStyle);

        btnStyle
                = "-fx-focus-color: transparent; "
                + "-fx-border-width: 2;"
                + "-fx-border-color: #00f;"
                + "-fx-border-radius: 10;"
                + "-fx-text-fill: white;"
                + "-fx-background-color: rgba(30, 30, 30, 0.5);"
                + "-fx-cursor: hand;"
                + "-fx-font-size: 18;"
                + "-fx-padding: 10 0 10 0;"
                + "-fx-pref-width: 220;"
                + "-fx-pref-height: 40;"
                + "-fx-padding: 10 0 10 0;";

        btnPlayGame.setStyle(btnStyle);

        playButtonPane.setPrefSize(640, 300);
        playButtonPane.getChildren().add(btnPlayGame);

        topMenuBox.setPadding(new Insets(0, 0, 0, 50));

        topMenuBox.getChildren().addAll(btnExit, btnBack, btnCallFriend, btnAskAudience, btnDeleteTwoAnswers);
        answersPane.getChildren().addAll(answer1.getPane(), answer2.getPane(), answer3.getPane(), answer4.getPane());
        vBox.getChildren().addAll(topMenuBox, playButtonPane, questionShape, answersPane);
        hBox.getChildren().addAll(vBox, moneyBox);

        hBox.autosize();

        hBox.setTranslateX((WIDTH / 2) - (hBox.getWidth() / 2));
        hBox.setTranslateY((HEIGHT / 2) - (hBox.getHeight() / 2));

        this.getChildren().add(hBox);
        addMoneyBox();

        btnExit.setOnAction(e -> {
            Platform.exit();
        });

        btnBack.setOnAction(e -> {
            questionShape.setText("");
            mySounds.clickSound();
            Main.STAGE.getScene().setRoot(Main.PANE_MENU);
            timeline.stop();
            timeline = null;
            questions = null;
            vBox.getChildren().set(1, playButtonPane);
            answer1.setText("");
            answer1.setDefaultBg();
            answer1.setVisible(true);
            answer2.setText("");
            answer2.setDefaultBg();
            answer2.setVisible(true);
            answer3.setText("");
            answer3.setDefaultBg();
            answer3.setVisible(true);
            answer4.setText("");
            answer4.setDefaultBg();
            answer4.setVisible(true);
            initialValues();
            btnCallFriend.setDisable(false);
            btnAskAudience.setDisable(false);
            btnDeleteTwoAnswers.setDisable(false);
        });

        btnCallFriend.setOnAction(e -> {
            mySounds.clickSound();
            btnCallFriend.setDisable(true);
            RemainingSeconds = 40;
            aFriendIsCalled = true;
        });

        btnAskAudience.setOnAction(e -> {
            mySounds.clickSound();
            btnAskAudience.setDisable(true);
            RemainingSeconds = 40;
            userIsAskingAudience = true;
        });

        btnDeleteTwoAnswers.setOnAction(e -> {
            mySounds.clickSound();
            btnDeleteTwoAnswers.setDisable(true);

            if (question.getAnswer(0).isCorrect == false && hiddenButtonsCounter < 2) {
                answer1.hide();
                hiddenButtonsCounter++;
            }

            if (question.getAnswer(1).isCorrect == false && hiddenButtonsCounter < 2) {
                answer2.hide();
                hiddenButtonsCounter++;
            }

            if (question.getAnswer(2).isCorrect == false && hiddenButtonsCounter < 2) {
                answer3.hide();
                hiddenButtonsCounter++;
            }

            if (question.getAnswer(3).isCorrect == false && hiddenButtonsCounter < 2) {
                answer4.hide();
                hiddenButtonsCounter++;
            }
        });

        btnPlayGame.setOnAction(e -> {
            vBox.getChildren().set(1, timerLabel);
            playGame();
        });

    }

    // هذه الدالة تستخدم لوضع خلفية للعبة, مع الإشارة إلى أننا استدمنا أيضاً نفس الخلفية التي وضعناها في كل الصفحات
    public void setGameImage() {
        this.setBackground(Main.GetBGImage());
    }

    // هذه الدالة تستخدم لإنشاء و إضافة عناصر الحاوية التي يظهر فيها رصيد المستخدم
    public void addMoneyBox() {
        moneyLabels.add(new Label("100"));
        moneyLabels.add(new Label("200"));
        moneyLabels.add(new Label("300"));
        moneyLabels.add(new Label("500"));
        moneyLabels.add(new Label("1000"));
        moneyLabels.add(new Label("2000"));
        moneyLabels.add(new Label("4000"));
        moneyLabels.add(new Label("8000"));
        moneyLabels.add(new Label("16000"));
        moneyLabels.add(new Label("22000"));
        moneyLabels.add(new Label("64000"));
        moneyLabels.add(new Label("125000"));
        moneyLabels.add(new Label("250000"));
        moneyLabels.add(new Label("500000"));
        moneyLabels.add(new Label("1000000"));

        for (int i = moneyLabels.size() - 1; i > -1; i--) {
            moneyLabels.get(i).setAlignment(Pos.CENTER);
            moneyLabels.get(i).setStyle(
                    "-fx-border-color: #aaa;"
                    + "-fx-border-radius: 5;"
                    + "-fx-background-color: black;"
                    + "-fx-text-fill: yellow;"
                    + "-fx-font-family: calibry;"
                    + "-fx-font-size: 17;"
                    + "-fx-text-alignment: center;"
                    + "-fx-pref-width: 120;"
                    + "-fx-pref-height: 30;"
            );
            moneyBox.getChildren().add(moneyLabels.get(i));
        }
        moneyBox.setAlignment(Pos.CENTER_RIGHT);
    }

}
