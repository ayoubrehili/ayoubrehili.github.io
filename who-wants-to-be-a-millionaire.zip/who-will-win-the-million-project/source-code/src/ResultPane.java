import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

// حتى يظهر محتواه في وسط النافذة StackPane يرث من الكلاس ResultPane هنا جعلنا الكلاس
// حتى يكون حجمه مطابق لحجم شاشة المستخدم ScreenBounds و جعلناه يطبق الإنترفيس
public class ResultPane extends StackPane implements ScreenBounds {
    
    // حتى نستطيع إستدعاء دوال تشغيل الأصوات التي جهزناها فيه Sounds هنا قمنا بإنشاء كائن من الكلاس
    Sounds mySounds = new Sounds();
    
    // ResultPane هنا منا بتعريف جميع الأشياء التي سنعرضها في الحاوية التي سيمثلها الكائن الذي نرجعه من الكلاس
    static Label label = new Label();
    Button buttonClose = new Button("خروج");
    Button buttonRetry = new Button("إلعب من جديد");
    VBox vBox = new VBox(20);

    // هذا كونستركتور الكلاس
    public ResultPane() {

        // ResultPane كخلفية للحاوية التي سنحصل عليها عند إنشاء كائن من الكلاس GetBGImage() هنا قمنا بوضع الصورة التي ترجعها الدالة
        this.setBackground(Main.GetBGImage());

        // Label هنا قمنا بتجهيز التصميم الذي نريد تطبيقه على الكائن
        String labelStyle
                = "-fx-text-fill: white; "
                + "-fx-font-size: 24;"
                + "-fx-padding: 0 0 20 0;"
                + "-fx-alignment: CENTER;";

        // buttonRetry و buttonClose هنا قمنا بتجهيز التصميم الذي نريد تطبيقه على الكائنين
        String btnStyle
                = "-fx-focus-color: transparent; "
                + "-fx-border-width: 2;"
                + "-fx-border-color: #00f;"
                + "-fx-border-radius: 10;"
                + "-fx-text-fill: white;"
                + "-fx-background-color: rgba(30, 30, 30, 0.5);"
                + "-fx-cursor: hand;"
                + "-fx-font-size: 18;"
                + "-fx-padding: 10 0 10 0;"
                + "-fx-pref-width: 220;"
                + "-fx-pref-height: 40;"
                + "-fx-padding: 10 0 10 0;";

        // buttonRetry و buttonClose, label هنا قمنا بتطبيق التصاميم على الكائنات
        label.setStyle(labelStyle);
        buttonClose.setStyle(btnStyle);
        buttonRetry.setStyle(btnStyle);

        // لكي يظهروا عامودياً تحت بعضهم البعض و في وسط الحاويةvBox في الحاوية buttonRetry و buttonClose, label هنا قمنا بإضافة الكائنات
        vBox.getChildren().addAll(label, buttonRetry, buttonClose);
        vBox.setAlignment(Pos.CENTER);
        
        // أي في الحاوية التي تمثل الصفحة نفسها .ResultPane في الكائن الذي ستم إنشاؤه من الكلاس vBox هنا أضفنا الحاوية
        this.getChildren().addAll(vBox);

        // buttonRetry هنا قمنا بتحديد ما سيحدث عند النقر على الزر الذي يمثله الكائن
        buttonRetry.setOnAction(e -> {
            mySounds.clickSound();
            Main.STAGE.getScene().setRoot(new GamePane());
        });

        // buttonClose هنا قمنا بتحديد ما سيحدث عند النقر على الزر الذي يمثله الكائن
        buttonClose.setOnAction(e -> {
            Platform.exit();
        });

    }

    public static void setResult(int answeredQuestions, int totalEarning) {
        if (answeredQuestions == 0) {
            label.setText("لم تعرف إجابة أي سؤال لذلك لم تفز بأي مبلغ !");
        }
        else if (answeredQuestions < 15){
            label.setText("لقد تخطيت السؤال رقم " + answeredQuestions + " و فزت بمبلغ " + totalEarning + "$");
        }
        else if (answeredQuestions == 15) {
            label.setText("لقد تخطيت جميع الأسئلة و فزت بمبلغ "+ totalEarning + "$");            
        }
    }
    
}
